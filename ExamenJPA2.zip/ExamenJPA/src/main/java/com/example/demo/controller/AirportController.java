package com.example.demo.controller;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Airport;
import com.example.demo.service.AirportService;

@RestController
@RequestMapping("/Airport")
public class AirportController {
	private AirportService airportService;
	
	public List<Airport> listadoAirport() {
		return null;
	}
}
