package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Airport;

public interface AirportService {
	
	public Airport insertarAirport(String name);
	public List<Airport> listadoAirport();
	public Airport buscarPorId(int id);
	public void eliminarAirport(int id);

}
