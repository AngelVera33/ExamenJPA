package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Country;


public interface CountryService {
	public Country insertarCountry(String code, String name);
	public List<Country> listadoCountry();
	public Country buscarPorId(int id);
	public void eliminarCountry(int id);

}
