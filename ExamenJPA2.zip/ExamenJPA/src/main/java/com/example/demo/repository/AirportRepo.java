package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Airport;

public interface AirportRepo extends JpaRepository<Airport, Integer> {
	
	public Optional<Airport> findByName(String name);

}
