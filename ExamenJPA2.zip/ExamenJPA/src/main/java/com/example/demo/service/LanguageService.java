package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Language;

public interface LanguageService {
	public Language insertarLanguage(String code, String name);
	public List<Language> listadoLanguage();
	public Language buscarPorId(int id);
	public void eliminarLanguage(int id);
}
