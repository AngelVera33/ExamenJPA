package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Airport;
import com.example.demo.repository.AirportRepo;
import com.example.demo.service.AirportService;

public class AirportServiceImpl implements AirportService {

	@Autowired
	private AirportRepo airportRepo;
	
	@Override
	public Airport insertarAirport(String name) {
		Airport al=new Airport();
		al.setName(name);
		return airportRepo.save(al);
	}

	@Override
	public List<Airport> listadoAirport() {
		
		return airportRepo.findAll();
	}

	@Override
	public Airport buscarPorId(int id) {
		
		return airportRepo.findById(id).orElse(null);
	}

	@Override
	public void eliminarAirport(int id) {
		airportRepo.deleteById(id);

	}

}
