package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepo;
import com.example.demo.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepo employeeRepo;

	@Override
	public Employee insertarEmployee(String surname, String firstname) {
		Employee al=new Employee();
		al.setSurname(surname);
		al.setFirstname(firstname);
		return employeeRepo.save(al);
	}

	@Override
	public List<Employee> listadoEmployee() {
		
		return employeeRepo.findAll();
	}

	@Override
	public Employee buscarPorId(int id) {
		
		return employeeRepo.findById(id).orElse(null);
	}

	@Override
	public void eliminarEmployee(int id) {
		employeeRepo.deleteById(id);
	}

}
