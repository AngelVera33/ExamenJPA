package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeService {

	public Employee insertarEmployee(String surname, String firstname);
	public List<Employee> listadoEmployee();
	public Employee buscarPorId(int id);
	public void eliminarEmployee(int id);
}
