package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Language;
import com.example.demo.repository.LanguageRepo;
import com.example.demo.service.LanguageService;

public class LanguageServiceImpl implements LanguageService {

	@Autowired
	private LanguageRepo languageRepo;
	
	@Override
	public Language insertarLanguage(String code, String name) {
		Language al=new Language();
		al.setCode(code);
		al.setName(name);
		return languageRepo.save(al);
	}

	@Override
	public List<Language> listadoLanguage() {
		
		return languageRepo.findAll();
	}

	@Override
	public Language buscarPorId(int id) {
		
		return languageRepo.findById(id).orElse(null);
	}

	@Override
	public void eliminarLanguage(int id) {
		languageRepo.deleteById(id);

	}

}
