package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.Country;
import com.example.demo.repository.CountryRepo;
import com.example.demo.service.CountryService;

public class CountryServiceImpl implements CountryService {
	
	@Autowired
	private CountryRepo countryRepo;

	@Override
	public Country insertarCountry(String code, String name) {
		Country al=new Country();
		al.setCode(code);
		al.setName(name);
		return countryRepo.save(al);
	}

	@Override
	public List<Country> listadoCountry() {
		
		return countryRepo.findAll();
	}

	@Override
	public Country buscarPorId(int id) {
		
		return countryRepo.findById(id).orElse(null);
	}

	@Override
	public void eliminarCountry(int id) {
		countryRepo.deleteById(id);

	}

}
